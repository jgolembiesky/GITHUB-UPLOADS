
public class Driver {
	public static void main(String[] args){
		IntSLList ll = new IntSLList();
		ll.addToHead(8);
		ll.addToHead(7);
		ll.addToTail(20);
		ll.addToHead(8);
		ll.addToTail(21);
		ll.addToHead(7);
		ll.addToTail(23);
		ll.addToHead(8);
		ll.addToTail(22);
		ll.addToHead(7);
		ll.addToTail(20);
		ll.addToHead(100);
		ll.addToTail(67);
		ll.addToHead(88);
		ll.addToTail(29);
		ll.printAll();
		ll.addToTail(-12);
		ll.printAll();
		ll.sum();
		ll.max();
		ll.min();
		ll.removeDuplicates();
		ll.removeMedian();
	}
}
