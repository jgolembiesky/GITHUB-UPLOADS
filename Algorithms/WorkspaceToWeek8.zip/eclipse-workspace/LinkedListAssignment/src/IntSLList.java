

public class IntSLList {
 protected IntSLLNode head, tail;
 public IntSLList(){
	 head = tail = null;
 }
 public boolean isEmpty(){
	 return head == null;
 }
 public void addToHead(int el){
	 head = new IntSLLNode(el, head);
	 if (tail == null)
		 tail = head;
 }
 public void addToTail(int el){
	 if (!isEmpty()){
		 tail.next = new IntSLLNode(el);
		 tail = tail.next;
	 }
 }
 public int deleteFromHead(){
	 int el = head.info;
	 if(head == tail){
		 head = tail = null;
	 }
	 else head = head.next;
	 return el;
 }
 public int deleteFromTail(){
	 int el = tail.info;
	 if(head == tail)
		 head = tail = null;
	 else{
		 IntSLLNode tmp;
		 for(tmp = head; tmp.next != tail; tmp = tmp.next);
			 tail = tmp;
			 tail.next = null;
		 
	 }
	 return el;
 }
 public void printAll(){
	 System.out.println("Printing All Values:");
	 for (IntSLLNode tmp = head; tmp != null; tmp = tmp.next)
		 System.out.println(tmp.info + " ");
 }
 public boolean isInList (int el){
	 IntSLLNode tmp;
	 for (tmp = head; tmp != null &&tmp.info != el; tmp = tmp.next);
	 return tmp != null;
 }
 public void delete (int el){
	 if (!isEmpty())
		 if (head == tail && el == head.info)
			 head = tail = null;
		 else if (el == head.info)
			 head = head.next;
		 else{
			 IntSLLNode pred, tmp;
			 for (pred = head, tmp = head.next;
			      tmp != null && tmp.info != el;
					 pred = pred.next, tmp = tmp.next);
			 if (tmp != null){
				 pred.next = tmp.next; 
				 if (tmp == tail)
					 tail = pred;
			 }
		 }
 }
 public void sum() {
	 int sum = 0;
	 for (IntSLLNode tmp = head; tmp != null; tmp = tmp.next) {
		 sum += tmp.info;
	 }
	 System.out.println("Sum = " + sum);
 }
 public void max() {
	 int max = head.info;
	 for (IntSLLNode tmp = head; tmp != null; tmp = tmp.next) {
		if (max < tmp.info) {
			max = tmp.info;
		}
	 }
	 System.out.println("Max = " + max);
 }
 public void min() {
	 int min = head.info;
	 for (IntSLLNode tmp = head; tmp != null; tmp = tmp.next) {
		if (min > tmp.info) {
			min = tmp.info;
		}
	 }
	 System.out.println("Min = " + min);
 }
 public void removeDuplicates() {
	 System.out.println("Removing duplicates:");
	 printAll();
	 for (IntSLLNode tmp = head; tmp != null; tmp = tmp.next) {
		 for(IntSLLNode tmp2 = tmp.next; tmp2!=null; tmp2 = tmp2.next) {
			 if(tmp.info == tmp2.info) {
				 System.out.println("Matched " + tmp.info + " and " + tmp2.info + ". Deleting duplicate. ");
				 delete(tmp2.info);
			 }
		 }
	 }
	 System.out.println("Final LinkedList:");
	printAll();
 }
 public void removeMedian() {
	 System.out.println("Removing Median:");
	 int i = 0;
	 for (IntSLLNode tmp = head; tmp != null; tmp = tmp.next) {
	  i++;
	 }
	 int[] values = new int[i];
	 int j = 0;
	 for (IntSLLNode tmp = head; tmp != null; tmp = tmp.next) {
		 values[j] = tmp.info;
		 j++;
		 }
	 sort(values);
	 int half = (int) Math.round(i/2);
	 int toRemove = values[half];
	 delete(toRemove);
	 System.out.println("Median of " + toRemove + " was removed.");
	 printAll();
	 
 }
 public int[] sort (int[] data) {
	
	 int len = data.length;
	 for (int pass = 1; pass<len; pass++) {
		 //System.out.println("Pass =  " + pass);
		 for (int compares = 0; compares < len-pass; compares++) {
			 //System.out.println(compares);
			 if (data[compares] < data[compares + 1]) {
				 //Swap
				 int temp = data[compares];
				 data[compares] = data[compares + 1];
				 data[compares+ 1] = temp;
			 }
		 }
	 }
	 return data;
 }
} 
