import java.util.*;
public class FindBoss {

	public static void main(String[] args) {
	int boss = 1;
	int grid1[][] = generateGrid(8,8);
	hideBoss(grid1.length, grid1, boss);
	findBoss(grid1, boss);
	int grid2[][] = generateGrid(20,20);
	hideBoss(grid2.length, grid2, boss);
	findBoss(grid2, boss);
	int grid3[][] = generateGrid(50,50);
	hideBoss(grid3.length, grid3, boss);
	findBoss(grid3, boss);
	int grid4[][] = generateGrid(100,100);
	hideBoss(grid4.length, grid4, boss);
	findBoss(grid4, boss);
	int grid5[][] = generateGrid(1000,1000);
	hideBoss(grid5.length, grid5, boss);
	findBoss(grid5, boss);
}
	

	public static int[][] generateGrid(int rows, int columns){
		return new int[rows][columns];
	}
	public static void hideBoss(int gridLength, int[][] grid, int boss) {
		
		int row =(int)Math.floor(Math.random() * gridLength);
		int column=(int)Math.floor(Math.random() * gridLength);
		grid[row][column] = boss;
	}
	public static void findBoss(int[][] grid, int boss) {
		long startTime = System.nanoTime();
		for (int i = 0; i < grid.length; i++) {
			for(int j = 0; j < grid.length; j++) {
				if(grid[i][j] == boss) {
					System.out.println("Boss found at Row " + (i + 1) + " Column " + (j + 1));
					long endTime = System.nanoTime();
					long difference = endTime - startTime;
					System.out.println("Time in nanoseconds: " + difference);
				}
			}
		}
	}
}