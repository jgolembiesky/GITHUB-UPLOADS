public class FindBoss2 {

	public static void main(String[] args) {
		int boss = 1;
		int timesToRun = 10;
		for (int i = 0; i < timesToRun; i ++)
		{
			int randomNumber = (int)Math.floor(Math.random() * 1000);
			int[][] grid = generateGrid(randomNumber);
			hideBoss(randomNumber,grid, boss);
			findBoss(grid, boss);
		}
}
	

	public static int[][] generateGrid(int randomNumber){
		return new int[randomNumber][randomNumber];
	}
	public static void hideBoss(int gridLength, int[][] grid, int boss) {
		
		int row =(int)Math.floor(Math.random() * gridLength);
		int column=(int)Math.floor(Math.random() * gridLength);
		grid[row][column] = boss;
	}
	public static void findBoss(int[][] grid, int boss) {
		long startTime = System.nanoTime();
		for (int i = 0; i < grid.length; i++) {
			for(int j = 0; j < grid.length; j++) {
				if(grid[i][j] == boss) {
					System.out.println("Grid is of size " + grid.length + " by " + grid.length );
					System.out.println("Boss found at Row " + (i + 1) + " Column " + (j + 1));
					long endTime = System.nanoTime();
					long difference = endTime - startTime;
					System.out.println("Time in nanoseconds: " + difference);
				}
			}
		}
	}
}