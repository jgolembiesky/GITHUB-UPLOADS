
public class ThisIsAWordNoFunction2 {
	public static void main(String[] args) {
		long startTime = System.nanoTime();
		String theInput = "This is a word";
		String theOutput = "";
		int stopCounter = 0;
		
		for(int i = theInput.length() - 1; i >= 0; i--) {
			stopCounter++;
			if(theInput.charAt(i) == ' ' | i == 0 ) {
				int k = i;
				if(i == 0) {
					theOutput += ' ';
				}
				for (int j = 0; j < stopCounter; j++) {
					
					theOutput += theInput.charAt(k);
					k++;
				}
				stopCounter = 0;
			}
		}
		System.out.println(theOutput);
		long endTime = System.nanoTime();
		long difference = endTime - startTime;
		System.out.println("Time cost in nanoseconds: " + difference);
	}
}