
public class Bubble {
	
 int[] data;
 static long startTime;
 static long endTime;
 static long difference;
 public Bubble() {
 data = new int[100000];
 for(int i = 0; i < data.length; i++) {
	 data[i] = (int) Math.ceil(Math.random() * 100);
 }
	 
 }
 
 public int[] sort (int[] data) {
	 startTime = System.nanoTime();
	 int len = data.length;
	 for (int pass = 1; pass<len; pass++) {
		 //System.out.println("Pass =  " + pass);
		 for (int compares = 0; compares < len-pass; compares++) {
			 //System.out.println(compares);
			 if (data[compares] < data[compares + 1]) {
				 //Swap
				 int temp = data[compares];
				 data[compares] = data[compares + 1];
				 data[compares+ 1] = temp;
			 }
		 }
	 }
	  endTime = System.nanoTime();
	  difference = endTime - startTime;
	 return data;
 }
 
 public void printData() {
	 for ( int i=0; i<data.length; i++) {
		 System.out.println(data[i]);
	 }
 }
 public static void main(String[] args) {
	
	 System.out.println("The unsorted order");
	 Bubble bubble = new Bubble();
	 bubble.printData();
	 bubble.sort(bubble.data);
	 System.out.println("The sorted order:");
	 bubble.printData();
	 
	 
	 System.out.println("Time in nanoseconds: " + difference);
 }
}
