
public class Fibonacci {
	public static void main (String[] args) {
	    int f = 0;
	    int g = 1;

	    for (int i = 1; i <= 10; i++) { // There is only one for loop in this function.
	        System.out.print(f + " "); // This qualifies the Fibonacci sequence to 
	        f = f + g;					//Have asymptotic complexity of O(N) (linear)
	        g = f - g;
	    } 

	    System.out.println();
	}
}
