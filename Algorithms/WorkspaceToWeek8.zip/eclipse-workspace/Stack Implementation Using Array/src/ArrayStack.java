
public class ArrayStack {


        private int[] data;

        public ArrayStack(int size) {

            data = new int[size];
           
            for(int i = 0; i< data.length; i++) {//Empty arrays contain 0's. we want to be able to hold 0's. 
            	data[i] = -1;					//Set all values to -1 so we know when it's holding a 0 for real.
            }

        }  

        public void clear() {

        	for(int i = 0; i< data.length; i++) { //Resetting all the values back to -1.(See constructor)
            	data[i] = -1;
            }

        }

          public void push(int element) {
        	 boolean resize = true;
        	 int[] data2;
        	 for(int i = 0; i< data.length; i++) {
        		 if(data[i] == -1)
        		 resize = false;
        	 }
        	 if(resize) {
        		 data2 = new int[data.length];
        		System.arraycopy(data, 0, data2, 0, data.length);
        		data2[data2.length -1] = -1;
        		 data = data2;
        	 }
        	
        	 for (int i = 0; i < data.length; i++) {
        		 if(data[i] == -1) {
        			 data[i] = element;
        			 break;
        		 }
        	 }
          }

          public int pop() {
        	  int number = 0;
        	  for(int i = data.length - 1; i >= 0; i--) {
        		  if(data[i] != -1) {
        			  number = data[i];
        			  data[i] = -1;
        			  break;
        		  }
        	  }
        	  return number;
          }

        public int size() {
        	int count = 0;
          for(int i = 0; i < data.length; i++) {
        	  if(data[i] != -1)
        		  count++;
          }
          	return count;
        }

      public boolean find(int element) {
    	  	boolean found = false;
           for(int i = 0; i < data.length; i++) {
        	   if(data[i] == element)
        		   found = true;
           }
    	  return found;

      }

     public int indexOf(int element) {
    	 int index = -1;
          for(int i = 0; i< data.length; i++) {
        	  if (data[i] == element)
        		 index = i;
          }

    	 return index;

     	}
     
 
}
