
public class ArrayQueue {

	private int[] data;

    public ArrayQueue(int size) {

        data = new int[size];
        for(int i = 0; i< data.length; i++) {//Empty arrays contain 0's. we want to be able to hold 0's. 
        	data[i] = -1;					//Set all values to -1 so we know when it's holding a 0 for real.
        }
    }  

    public void clear() {

    	for(int i = 0; i< data.length; i++) { //Resetting all the values back to -1.(See constructor)
        	data[i] = -1;
        }

    }

    public void enqueue(int element) {
    	for(int i = 0; i < data.length; i++) {
    		if(data[i] == -1) {
    			data[i] =  element;
    			break;
    	}
      }
    }
      public int dequeue() {
    	  int hold = data[0];
    	  for(int i = 0; i < data.length - 1; i++) {
    		  data[i] = data[i+1];
    	  }
    	  data[data.length - 1] = -1;
    	  return hold;
      }
      public int firstEl() {
       return data[0];
      }

    public int size() {
    	int count = 0;
        for(int i = 0; i < data.length; i++) {
      	  if(data[i] != -1)
      		  count++;
        }
        	return count;
    }

  public boolean find(int element) {

		boolean found = false;
        for(int i = 0; i < data.length; i++) {
     	   if(data[i] == element)
     		   found = true;
        }
 	  return found;

  }

 public int indexOf(int element) {

	 int index = -1;
     for(int i = 0; i< data.length; i++) {
   	  if (data[i] == element)
   		 index = i;
     }

	 return index;

  }

}
	
	
	

