

public class Driver {

            public static void main(String[] args) {

                ArrayStack as = new ArrayStack(2);

                // as.push(10);

               //as.push(11);

                // as.push(1);

               //as.push(0);

               //as.push(5);
               
               long startTime = System.nanoTime();
               for(int i = 0; i<= 1000000; i++) {
            	   as.push((int) Math.ceil(Math.random() * 100));
               }
               
               long endTime = System.nanoTime();
               long difference = endTime - startTime;
               System.out.println("Time cost in nanoseconds: " + difference);
               System.out.println(as.size()); // this should print 5

               System.out.println(as.pop()); // this should print 5
               
               ArrayQueue aq = new ArrayQueue(15);
               

               aq.enqueue(10);

               aq.enqueue(11);

               aq.enqueue(1);

               aq.enqueue(0);

               aq.enqueue(5);

               System.out.println(aq.size()); 

               System.out.println(aq.dequeue()); 
               

            }

}