
public class Problem2 {
	//Static bool for checking if it's the first iteration.
	public static boolean firstTime = true;
	public static void main(String[] args) {
		//Calls function
		String test = lookAndSay("1",10);
	}

	
	static String lookAndSay(String start, int iterations) {
		
		
		//If this is the last time it's supposed to run, reset firstTime boolean so it can be used again, and returns an empty string.
		if (iterations == 0) {
			firstTime = true;
			return "";
		}
		//If this is the first time, we just want to print the starting string one time as the first iteration.
		//We subtract one iteration, set firstTime = false, and start calling the function recursively.
		if (firstTime) {
			System.out.println(start);
			iterations--;
			firstTime = false;
			 return lookAndSay(start, iterations);
		}
		//After the first iteration, this will start coming into play.
		
		//Empty String for holding the new value, counter = 1 for how many times in a row the integers appear.
		String str = "";
		int counter = 1;
		//Put the String in a Char Array. Makes it nice and easy.
		char startChar[] = start.toCharArray();
		
		for(int i = 0; i < startChar.length; i++){
			//This is to make sure we don't go out of bounds, caught with an else below.
			if(i < startChar.length - 1) {
				//If this char equals the next char:
				if(startChar[i] == startChar[i+1]) {
					//we add it to the counter
					counter++;
				}
				else {
					//Otherwise, that's the end of that substring of consecutive numbers. Add the count of the number as well as whatever number we were counting to the string.
					str += String.valueOf(counter) + String.valueOf(startChar[i]);
					//Also, we're back to counting a new set of consecutive numbers. Set it back to 1.
					counter = 1;
				}
			}
			//This is the else that catches things going out of bounds above. Adds the counter value plus the last char in the char array.
			else {
				str += String.valueOf(counter) + String.valueOf(startChar[i]);
			}
			
		}
		
		//Print out the string, subtract an iteration, call the function again.
		System.out.println(str);
		iterations--;
		return lookAndSay(str, iterations);
	}
	
	
}
