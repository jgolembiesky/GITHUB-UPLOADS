
public class Problem1 {
	
 //Helps track when to stop the recursive Program.
	
 static int runCount = 0;
	
	public static void main(String[] args) {
		
		String test = "Welcome to Java";
		test = reverse(test);
		System.out.println(test);
		
	}

	
	public static String reverse(String str) {
		    //iterates every time it runs
			runCount++;
			
			//Function should only run N times. N = length of string
			if (str.length() + 1 == runCount) {	
				
			//Resets the counter so the code will work if the function is called
			//Again later. Returns empty quotes to confirm end of String.
				
			runCount = 0;
			return "";
			
			}
			
			else {
				//I use empty quotes as a little hack to use .charAt in a String.
				//The first time, this will take the first letter, 
				//The second time, it takes the second letter, and so on
				//Until the end of the string is reached (see code above)
				
				String hold = "" + str.charAt(runCount - 1);
				
				//Hold is now calling this function recursively, actively 
				//Reversing the order of the string with every call.
				
				hold = reverse(str) + hold;
				
				return hold;
				
			}
	}
	
	
}
