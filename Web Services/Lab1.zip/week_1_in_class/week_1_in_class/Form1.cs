﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace week_1_in_class
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_read_Click(object sender, EventArgs e)
        {
            XmlDocument document = new XmlDocument();
            document.Load(Application.StartupPath + "\\week_1_lab.xml");

            XmlElement element = document.DocumentElement;
    
            XmlNodeList version_date = document.GetElementsByTagName("version_date");
            XmlNodeList version = document.GetElementsByTagName("version");
            XmlNodeList contacts = document.GetElementsByTagName("contact");
        
            string contents = "";

           foreach(XmlNode node in version_date)
            {
                contents += node.Name + ": ";
                contents += node.InnerText + "\r\n"; 
            }
            foreach (XmlNode node in version)
            {
                contents += node.Name + ": ";
                contents += node.InnerText + "\r\n";
            } 
            for (int count = 0; count < contacts.Count; count++)
            {
                XmlNodeList child_node = contacts[count].ChildNodes;
                for (int j_count = 0; j_count < child_node.Count; j_count++)
                {
                    contents += child_node[j_count].Name + ": ";
                    contents += child_node[j_count].InnerText + " \r\n";
                }
            }

            txt_contents.Text = contents;
        }

        private void txt_contents_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
