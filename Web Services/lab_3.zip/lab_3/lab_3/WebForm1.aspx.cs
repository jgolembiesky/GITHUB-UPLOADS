﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.XPath;
using System.Net;

namespace lab_3
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            HttpWebRequest my_http_web_request = null; //Declare an Http-specific implementation of the WebRequest class.
            HttpWebResponse my_http_web_response = null;//Declare an HTTP-specific implementation of the WebResponse class.
            XmlTextReader my_xml_reader = null;
            XPathNavigator nav;
            XPathDocument doc_nav;
            XPathNodeIterator node_iter = null;
            //Create Request
            String weather_url = "http://api.wunderground.com/api/105a3d792a8b4dd2/forecast/q/MA/Boston.xml";

            my_http_web_request = (HttpWebRequest)HttpWebRequest.Create(weather_url);
            my_http_web_request.Method = "GET";
            my_http_web_request.ContentType = "text/xml; encoding='utf-8'";

            my_http_web_response = (HttpWebResponse)my_http_web_request.GetResponse();

            //Load response stream into XML reader
            my_xml_reader = new XmlTextReader(my_http_web_response.GetResponseStream());

            doc_nav = new XPathDocument(my_xml_reader);
            //Create a navigator to query with XPath.

            nav = doc_nav.CreateNavigator();
         
            node_iter = nav.Select("//forecast//forecastdays/forecastday");
            string info = "";
            
            while (node_iter.MoveNext())
            {
                XPathNodeIterator weather_info = node_iter.Current.SelectChildren(XPathNodeType.Element);
                info += weather_info.Current.SelectSingleNode("title") + Environment.NewLine;
                info += weather_info.Current.SelectSingleNode("fcttext") + Environment.NewLine;

            }
            TextBox1.Text = info;
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string zip_code = TextBox2.Text;
            string postal_url = "http://api.geonames.org/findNearbyPostalCodes?postalcode=" + zip_code +  "&country=US&radius=25&username=jhg_neit&style=full";
            //Create Request
            HttpWebRequest myHttpWebRequest =(HttpWebRequest)HttpWebRequest.Create(postal_url);
            myHttpWebRequest.Method = "GET";
            myHttpWebRequest.ContentType = "text/xml; encoding = 'utf-8'";
            //Get Response
            HttpWebResponse myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();

            //Load response stream into XMLReader
            XmlTextReader myXMLReader = new XmlTextReader(myHttpWebResponse.GetResponseStream());

            
            XPathDocument doc_nav = new XPathDocument(myXMLReader);
            XPathNavigator nav = doc_nav.CreateNavigator();
            //Create a navigator to query with XPath.

            XPathNodeIterator codes = nav.Select("//geonames/code");
            string output = "";
            while (codes.MoveNext())
            {
                output += codes.Current.SelectSingleNode("postalcode") + "-" + codes.Current.SelectSingleNode("name").Value + Environment.NewLine;
            }
            TextBox3.Text = output;

        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            string zip_code = TextBox4.Text;
            string postal_url = "http://api.geonames.org/postalCodeSearch?postalcode=" + zip_code + "&maxRows=10&username=jhg_neit&style=full";
            //Create Request
            HttpWebRequest myHttpWebRequest = (HttpWebRequest)HttpWebRequest.Create(postal_url);
            myHttpWebRequest.Method = "GET";
            myHttpWebRequest.ContentType = "text/xml; encoding = 'utf-8'";
            //Get Response
            HttpWebResponse myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();

            //Load response stream into XMLReader
            XmlTextReader myXMLReader = new XmlTextReader(myHttpWebResponse.GetResponseStream());


            XPathDocument doc_nav = new XPathDocument(myXMLReader);
            XPathNavigator nav = doc_nav.CreateNavigator();
            //Create a navigator to query with XPath.

            XPathNodeIterator codes = nav.Select("//geonames/code");
            string output = "";
            while (codes.MoveNext())
            {
                output += codes.Current.SelectSingleNode("postalcode") + "-" + codes.Current.SelectSingleNode("name").Value + Environment.NewLine;
            }
            TextBox5.Text = output;
        }
    }
}