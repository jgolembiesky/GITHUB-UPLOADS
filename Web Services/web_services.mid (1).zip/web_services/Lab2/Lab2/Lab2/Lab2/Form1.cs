﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.XPath;
namespace Lab2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_generate_Click(object sender, EventArgs e)
        {
            XPathNavigator nav;
            XPathDocument doc_nav;

            string file_name = Application.StartupPath + "\\OrderInfo.xml";
            doc_nav = new XPathDocument(file_name);
            nav = doc_nav.CreateNavigator();

            string info = "";
            //Billing Info
            //Name, Address, City, State, ZipCode
            info += "Invoice" + Environment.NewLine + Environment.NewLine;
            info += "Billing Info" + Environment.NewLine;
            info += nav.SelectSingleNode("//BillingInformation/Name").Value + Environment.NewLine;
            info += nav.SelectSingleNode("//Order/BillingInformation/Address").Value + Environment.NewLine;
            info += nav.SelectSingleNode("//Order/BillingInformation/City").Value + Environment.NewLine;
            info += nav.SelectSingleNode("//Order/BillingInformation/State").Value + Environment.NewLine;
            info += nav.SelectSingleNode("//Order/BillingInformation/ZipCode").Value + Environment.NewLine;
            info += Environment.NewLine;
            //Shipping Info
            //Name,Address,City,State, ZipCode
            info += "Shipping Info" + Environment.NewLine;
            info += nav.SelectSingleNode("//Order/ShippingInformation/Name").Value + Environment.NewLine;
            info += nav.SelectSingleNode("//Order/ShippingInformation/Address").Value + Environment.NewLine;
            info += nav.SelectSingleNode("//Order/ShippingInformation/City").Value + Environment.NewLine;
            info += nav.SelectSingleNode("//Order/ShippingInformation/State").Value + Environment.NewLine;
            info += nav.SelectSingleNode("//Order/ShippingInformation/ZipCode").Value + Environment.NewLine;

            //Item Info
            

            XPathNodeIterator order = nav.Select("//Order/Items/Item");
            int item = 1;
            while (order.MoveNext())
            {
                info += "Item " + item + Environment.NewLine + Environment.NewLine;
                info += order.Current.SelectSingleNode("PartNo").Value + Environment.NewLine;
                info += order.Current.SelectSingleNode("Description").Value + Environment.NewLine;
                info += order.Current.SelectSingleNode("UnitPrice").Value + Environment.NewLine;
                info += order.Current.SelectSingleNode("Quantity").Value + Environment.NewLine;
                info += order.Current.SelectSingleNode("TotalCost").Value + Environment.NewLine;
                info += order.Current.SelectSingleNode("//CustomerOptions/Size").Value + Environment.NewLine;
                info += order.Current.SelectSingleNode("//CustomerOptions/Color").Value + Environment.NewLine + Environment.NewLine;
                item++;
            }
            info += "Count of purchased items: " + nav.Evaluate("count(//Item)") + Environment.NewLine;
            info += "Total Cost: " + nav.Evaluate("sum(//TotalCost)");
            txt_invoice.Text = info;
        }

        private void txt_invoice_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
