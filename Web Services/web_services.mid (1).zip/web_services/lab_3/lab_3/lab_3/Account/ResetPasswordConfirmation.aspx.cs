﻿using System.Web.UI;

namespace lab_3.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}