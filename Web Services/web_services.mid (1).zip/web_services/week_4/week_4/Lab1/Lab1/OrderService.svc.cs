﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.XPath;

namespace Lab1
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class OrderService : IOrderService
    {
        
     


        public string GetNumberOfOrders()
        {
            XPathDocument docNav;
            XPathNavigator nav;

            string directory = HttpContext.Current.Server.MapPath(".");
            string strFilename = directory + "\\" + "OrderInfoLab3.xml";
            docNav = new XPathDocument(strFilename);
            nav = docNav.CreateNavigator();
            return nav.Evaluate("count(//Order)").ToString();
        }
        public double GetTotalCostForAnOrder(int OrderID)
        {
            XPathDocument docNav;
            XPathNavigator nav;

            string directory = HttpContext.Current.Server.MapPath(".");
            string strFilename = directory + "\\" + "OrderInfoLab3.xml";
            docNav = new XPathDocument(strFilename);
            nav = docNav.CreateNavigator();
            return (double)nav.Evaluate("sum(//TotalCost)");
           
        }
        public Item[] GetItemListForOrder(int OrderID)
        {   
            XPathDocument docNav;
            XPathNavigator nav;

            string directory = HttpContext.Current.Server.MapPath(".");
            string strFilename = directory + "\\" + "OrderInfoLab3.xml";
            docNav = new XPathDocument(strFilename);
            nav = docNav.CreateNavigator();
            Item[] itemList = new Item[(int)nav.Evaluate("count(//Item)")];
            XPathNodeIterator order = nav.Select("//Order/Items/Item");
            int iterator = 0;
            while (order.MoveNext())
            {
                Item item = new Item();
                item.PartNo = order.Current.SelectSingleNode("PartNo").Value;
                item.Description = order.Current.SelectSingleNode("Description").Value;
                item.UnitPrice = order.Current.SelectSingleNode("UnitPrice").Value;
                item.Quantity = order.Current.SelectSingleNode("Quantity").Value;
                item.TotalCost = order.Current.SelectSingleNode("TotalCost").Value;
                item.Size = order.Current.SelectSingleNode("//CustomerOptions/Size").Value;
                item.Color = order.Current.SelectSingleNode("//CustomerOptions/Color").Value;

                itemList[iterator] = item;
                iterator++;
            }

            return itemList;
        }
        public int HowManyOrderedForAPartNo(string PartNo)
        {
            XPathDocument docNav;
            XPathNavigator nav;
            string directory = HttpContext.Current.Server.MapPath(".");
            string strFilename = directory + "\\" + "OrderInfoLab3.xml";
            docNav = new XPathDocument(strFilename);
            nav = docNav.CreateNavigator();
            return (int)nav.Evaluate("count(//Order/Items/Item[PartNo=\"" + PartNo + "\"])");
        }
        public BillingInformation GetBillingAddressForAnOrder(int OrderID)
        {
            BillingInformation billingInfo = new BillingInformation();
            XPathDocument docNav;
            XPathNavigator nav;
            string directory = HttpContext.Current.Server.MapPath(".");
            string strFilename = directory + "\\" + "OrderInfoLab3.xml";
            docNav = new XPathDocument(strFilename);
            nav = docNav.CreateNavigator();
            XPathNodeIterator billing = nav.Select("//Order[@id=" + OrderID + "]/BillingInformation");
            billingInfo.Name = billing.Current.SelectSingleNode("Name").Value;
            billingInfo.Address = billing.Current.SelectSingleNode("Address").Value;
            billingInfo.City = billing.Current.SelectSingleNode("City").Value; 
            billingInfo.State = billing.Current.SelectSingleNode("State").Value; 
            billingInfo.ZipCode = billing.Current.SelectSingleNode("ZipCode").Value; 
            return billingInfo;
        }

    }

    
}
