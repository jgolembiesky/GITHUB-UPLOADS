﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
namespace MVC1.ViewModels.Home
{
    public class DataViewModel
    {
        public DataViewModel(string[] data)
        {
            DataList = data.Select(c => new SelectListItem() { Text = c });
        }
        public IEnumerable<SelectListItem> DataList { get; private set; }
    }
}