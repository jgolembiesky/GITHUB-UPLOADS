﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC1.Models;
using System.Web.Mvc;

namespace MVC1.ViewModels.Home
{
    public class UsersListViewModel
    {
        public IEnumerable<User> UserList { get; private set; }
        public UsersListViewModel(IEnumerable<User> users)
        {
            UserList = users;
        }
     
    }
}