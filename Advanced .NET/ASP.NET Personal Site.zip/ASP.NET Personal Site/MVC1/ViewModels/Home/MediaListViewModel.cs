﻿using MVC1.Models;
using System.Web.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC1.ViewModels.Home
{
    public class MediaListViewModel
    { 
        public IEnumerable<Media> MediaList { get; private set;}

        public MediaListViewModel(IEnumerable<Media> medias)
        {
            MediaList = medias;
        }
    }
}