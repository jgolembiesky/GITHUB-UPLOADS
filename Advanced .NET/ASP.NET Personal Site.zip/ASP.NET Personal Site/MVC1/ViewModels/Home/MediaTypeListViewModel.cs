﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MVC1.Models;
using System.Web.Mvc;
namespace MVC1.ViewModels.Home
{
    public class MediaTypeListViewModel
    {
        public IEnumerable<SelectListItem> MediaTypesList { get; private set; }

        public MediaTypeListViewModel(IEnumerable<MediaType> mediaTypes)
        {
            MediaTypesList = mediaTypes.Select(c => new SelectListItem() { Text = c.Type });
        }
    }
}