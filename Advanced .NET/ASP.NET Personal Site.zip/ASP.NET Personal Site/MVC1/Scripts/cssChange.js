﻿$(document).ready(function () {
    $("table > tbody tr:odd").css("background-color", "#F7F7F7");
});