﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC1.Models;
using MVC1.ViewModels.Home;

namespace MVC1.Controllers
{
    public class MediaController : Controller
    {
        private MediaFactory Db = new MediaFactory();
        // GET: Media
        public ActionResult MediaList()
        {
            var factory = new MediaFactory();

            var viewModel = new MediaListViewModel(factory.Medias);
            return View(viewModel);
        }

        public ActionResult ListofMedia(string searchCriteria)
        { /*
            var factory = new MediaFactory();
            var media = new MediaFactory().Medias.ToList();
            return View(media);
            */
            var factory = new MediaFactory();
            IQueryable<Media> media = factory.Medias.OrderBy(p => p.Name);

            if (searchCriteria != null)
            {
                media = media.Where(p => p.Name.Contains(searchCriteria));
            }
            var medialist = media.Take(20).ToList();
            return View(medialist);
        }
        public ActionResult Details (int id)
        {
            var factory = new MediaFactory();
            Media found = factory.Medias.Where(p => p.Media_ID == id).FirstOrDefault();

            return View(found);
        }
    }
}