﻿using MVC1.Models;
using MVC1.ViewModels.Home;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC1.Controllers
{
    public class CarsController : Controller
    {
        // GET: Cars
        public ActionResult CarsList()
        {
            var factory = new CarFactory();
            var viewModel = new CarListViewModel(factory.Cars);

            return View(viewModel);
        }

    }
}