﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MVC1.Models;

namespace MVC1.Controllers
{
    public class Media2Controller : Controller
    {
        private Lesson8Context db = new Lesson8Context();

        // GET: Media2
        public ActionResult Index()
        {
            var media = db.Media.Include(m => m.MediaType);
            return View(media.ToList());
        }

        // GET: Media2/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Media media = db.Media.Find(id);
            if (media == null)
            {
                return HttpNotFound();
            }
            return View(media);
        }

        // GET: Media2/Create
        public ActionResult Create()
        {
            ViewBag.MediaType_ID = new SelectList(db.MediaTypes, "MediaType_ID", "Type");
            return View();
        }

        // POST: Media2/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Media_ID,Media_Type_ID,Name,Medium,Platform,Artist,Acquired_Date,Acquired_Price,Location,Is_Borrowed,Was_Sold,Was_Donated,Market_Price,Sold_Price,ImageName,MediaType_ID")] Media media)
        {
            if (ModelState.IsValid)
            {
                db.Media.Add(media);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.MediaType_ID = new SelectList(db.MediaTypes, "MediaType_ID", "Type", media.MediaType_ID);
            return View(media);
        }

        // GET: Media2/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Media media = db.Media.Find(id);
            if (media == null)
            {
                return HttpNotFound();
            }
            ViewBag.MediaType_ID = new SelectList(db.MediaTypes, "MediaType_ID", "Type", media.MediaType_ID);
            return View(media);
        }

        // POST: Media2/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Media_ID,Media_Type_ID,Name,Medium,Platform,Artist,Acquired_Date,Acquired_Price,Location,Is_Borrowed,Was_Sold,Was_Donated,Market_Price,Sold_Price,ImageName,MediaType_ID")] Media media)
        {
            if (ModelState.IsValid)
            {
                db.Entry(media).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.MediaType_ID = new SelectList(db.MediaTypes, "MediaType_ID", "Type", media.MediaType_ID);
            return View(media);
        }

        // GET: Media2/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Media media = db.Media.Find(id);
            if (media == null)
            {
                return HttpNotFound();
            }
            return View(media);
        }

        // POST: Media2/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Media media = db.Media.Find(id);
            db.Media.Remove(media);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
