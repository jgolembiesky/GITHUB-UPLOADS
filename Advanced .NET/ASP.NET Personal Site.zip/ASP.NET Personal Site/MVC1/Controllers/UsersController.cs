﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC1.Models;
using MVC1.ViewModels.Home;
namespace MVC1.Controllers
{
    public class UsersController : Controller
    {
        // GET: User
        public ActionResult UsersList()
        {
            var factory = new UsersFactory();
            var viewModel = new UsersListViewModel(factory.Users);
            return View(viewModel);
        }
    }
}