﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Globalization;
namespace MVC1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Games()
        {
            string[] games = {};
            ViewBag.Games = games;
            ViewBag.Message = "Games are awesome";
            return View();
        }

        public ActionResult Films()
        {
            string[] films = {};
            ViewBag.Films = films;
            return View();
        }
        public ActionResult Music()
        {
            string[] music = {};
            ViewBag.Music = music;
            return View();
        }
        public ActionResult Consoles()
        {
            string[] consoles = {};
            ViewBag.Consoles = consoles;
            return View();
        }
        public ActionResult Books()
        {   string[] books = {};
            ViewBag.Books = books;
            return View();
        }
        public ActionResult Action1()
        {
            CultureInfo[] languages = CultureInfo.GetCultures(CultureTypes.SpecificCultures);
            return View(languages);
        }
        public ActionResult Data()
        {   
            string[] data = { ".NET", "C#", "Java", "Unity", "Game Programming" };
            ViewBag.Data = data;
            ViewBag.Message = "Here are some areas I'd like to study";
            var viewModel = new ViewModels.Home.DataViewModel(data);
            return View(viewModel);
        }

        public ActionResult ShowLanguages()
        {
            var viewModel = new ViewModels.Home.ShowLanguagesViewModel(CultureInfo.GetCultures(CultureTypes.SpecificCultures));
            return View(viewModel);
        }

    }
}