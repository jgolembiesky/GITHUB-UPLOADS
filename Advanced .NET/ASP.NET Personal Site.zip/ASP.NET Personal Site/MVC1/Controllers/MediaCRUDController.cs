﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using MVC1.Models;
using System.Web.Helpers;
namespace MVC1.Controllers
{
    public class MediaCRUDController : Controller
    {
        private MediaFactory db = new MediaFactory();

        // GET: MediaCRUD
        public ActionResult Index()
        {
            return View(db.Medias.ToList());
        }

        // GET: MediaCRUD/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Media media = db.Medias.Find(id);
            if (media == null)
            {
                return HttpNotFound();
            }
            return View(media);
        }

        // GET: MediaCRUD/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: MediaCRUD/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Media_ID,MediaType_ID,Name,Medium,Platform,Artist,Acquired_Date,Acquired_Price,Location,Is_Borrowed,Was_Sold,Was_Donated,Market_Price,Sold_Price")] Media media)
        {
            if (ModelState.IsValid)
            {
                db.Medias.Add(media);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(media);
        }

        // GET: MediaCRUD/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Media media = db.Medias.Find(id);
            if (media == null)
            {
                return HttpNotFound();
            }
            return View(media);
        }

        // POST: MediaCRUD/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Media_ID,Media_Type_ID,Name,Medium,Platform,Artist,Acquired_Date,Acquired_Price,Location,Is_Borrowed,Was_Sold,Was_Donated,Market_Price,Sold_Price")] Media media)
        {
            if (ModelState.IsValid)
            {
                db.Entry(media).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(media);
        }

        // GET: MediaCRUD/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Media media = db.Medias.Find(id);
            if (media == null)
            {
                return HttpNotFound();
            }
            return View(media);
        }

        // POST: MediaCRUD/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Media media = db.Medias.Find(id);
            db.Medias.Remove(media);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        public ActionResult Picture (int id)
        {
            var factory = new MediaFactory();
            var media = factory.Medias.Where(p => p.Media_ID == id).FirstOrDefault();

            if (media == null)
            {
                return HttpNotFound();
            }

            var img = new WebImage(string.Format("~/Content/Images/{0}.jpg", media.ImageName));
            img.Resize(100, 100);

            return File(img.GetBytes(), "image/jpeg");
        }
    }
}
