﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace MVC1.Models
{
    public class MediaTypeFactory : DbContext
    {
        public DbSet<MediaType> MediaTypes { get; set;}

        public MediaTypeFactory()
        {
            Database.SetInitializer(new MediaTypeInitializer());
        }
    }
    public class MediaTypeInitializer : DropCreateDatabaseIfModelChanges<MediaTypeFactory>
    {
        protected override void Seed(MediaTypeFactory context)
        {
            {
                context.MediaTypes.Add(new MediaType()
                {
                    Type = "Book"
                });
                context.MediaTypes.Add(new MediaType()
                {
                    Type = "Video Game"
                });
                context.MediaTypes.Add(new MediaType()
                {
                    Type = "Music"
                });
                context.MediaTypes.Add(new MediaType()
                {
                    Type = "Movie"
                });
                context.MediaTypes.Add(new MediaType()
                {
                    Type = "Game Console"
                });
              
            }
        }
    }
}