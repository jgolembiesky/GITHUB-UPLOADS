﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace MVC1.Models
{
    public class MediaType
    {
        [Key]

        public int  MediaType_ID { get; set; }

        [Required(ErrorMessage = "Media Type is required")]
        [RegularExpression("..+", ErrorMessage = "Must be at least 2 characters long")]

        public string Type { get; set; }

        //public virtual ICollection<Media> Medias { get; set; }
    }
}