﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;

namespace MVC1.Models
{
    public class MediaFactory : DbContext
    {
        public DbSet<Media> Medias { get; set; }
        public MediaFactory(): base("name=DefaultConnection")
        {
            Database.SetInitializer(new MediaInitializer());
        }
    }
    public class MediaInitializer : DropCreateDatabaseIfModelChanges<MediaFactory>
    {
        protected override void Seed(MediaFactory context)
        {
            {
                context.Medias.Add(new Media()
                {
                    Media_Type_ID = 0,
                    Name = "You Are the Universe",
                    Medium = "Hardcover Book",
                    Artist = "Deepak Chopra",
                    Acquired_Date = new DateTime(2016, 10, 02),
                    Acquired_Price = 17.00,
                    Location = "Bookshelf",
                    Is_Borrowed = false,
                    Was_Sold = false,
                    Was_Donated = false,
                    Market_Price = 26.00,
                    ImageName = "youaretheuniverse"
                    });
                context.Medias.Add(new Media()
                {
                    Media_Type_ID = 0,
                    Name = "Ready Player One",
                    Medium = "Softcover Book",
                    Artist = "Ernest Cline",
                    Acquired_Date = new DateTime(2017, 11, 07),
                    Acquired_Price = 12.00,
                    Location = "Steve's House",
                    Is_Borrowed = true,
                    Was_Sold = false,
                    Was_Donated = false,
                    Market_Price = 18.00,
                    ImageName = "readyplayerone"
                });
                context.Medias.Add(new Media()
                {
                    Media_Type_ID = 1,
                    Name = "Doom",
                    Medium = "Digital",
                    Platform = "PC",
                    Artist = "id Software",
                    Acquired_Date = new DateTime(2016, 12, 25),
                    Acquired_Price = 15.00,
                    Location = "Steam Library",
                    Is_Borrowed = false,
                    Was_Sold = false,
                    Was_Donated = false,
                    Market_Price = 39.99,
                    ImageName = "doom"
                });
                context.Medias.Add(new Media()
                {
                    Media_Type_ID = 1,
                    Name = "The Legend of Zelda, A Link Between Worlds",
                    Medium = "Game Cartridge",
                    Platform = "Nintendo 3DS",
                    Artist = "Nintendo",
                    Acquired_Date = new DateTime(2015, 12, 25),
                    Acquired_Price = 0.00,
                    Location = "Regina's House",
                    Is_Borrowed = true,
                    Was_Sold = false,
                    Was_Donated = false,
                    Market_Price = 19.99,
                    ImageName = "alinkbetweenworlds"
                });
                context.Medias.Add(new Media()
                {
                    Media_Type_ID = 2,
                    Name = "Legend",
                    Medium = "Vinyl Record",
                    Artist = "Bob Marley",
                    Acquired_Date = new DateTime(2013, 08, 16),
                    Acquired_Price = 17.00,
                    Location = "Bookshelf",
                    Is_Borrowed = false,
                    Was_Sold = false,
                    Was_Donated = false,
                    Market_Price = 29.99,
                    ImageName = "legend"
                });
                context.Medias.Add(new Media()
                {
                    Media_Type_ID = 2,
                    Name = "Perhaps, I Suppose...",
                    Medium = "CD",
                    Artist = "Rufio",
                    Acquired_Date = new DateTime(2005, 05, 12),
                    Acquired_Price = 15.00,
                    Location = "Car",
                    Is_Borrowed = false,
                    Was_Sold = false,
                    Was_Donated = false,
                    Market_Price = 15.00,
                    ImageName = "perhapsisuppose"
                });
                context.Medias.Add(new Media()
                {
                    Media_Type_ID = 3,
                    Name = "Lord of the Rings Trilogy",
                    Medium = "DVD",
                    Artist = "Peter Jackson",
                    Acquired_Date = new DateTime(2014, 12, 25),
                    Acquired_Price = 0.00,
                    Location = "Bookshelf",
                    Is_Borrowed = false,
                    Was_Sold = false,
                    Was_Donated = false,
                    Market_Price = 19.99,
                    ImageName = "lotr"
                });
                context.Medias.Add(new Media()
                {
                    Media_Type_ID = 3,
                    Name = "Angry Video Game Nerd: The Movie",
                    Medium = "Digital",
                    Artist = "James Rolfe",
                    Acquired_Date = new DateTime(2016, 08, 08),
                    Acquired_Price = 4.99,
                    Location = "Steam Library",
                    Is_Borrowed = false,
                    Was_Sold = false,
                    Was_Donated = false,
                    Market_Price = 9.99,
                    ImageName = "avgn"
                });
                context.Medias.Add(new Media()
                {
                    Media_Type_ID = 4,
                    Name = "Nintendo Entertainment System",
                    Artist = "Nintendo",
                    Acquired_Date = new DateTime(2015, 04, 06),
                    Acquired_Price = 19.99,
                    Location = "TV Stand",
                    Is_Borrowed = false,
                    Was_Sold = false,
                    Was_Donated = false,
                    Market_Price = 59.99,
                    ImageName = "nes"
                });
                context.Medias.Add(new Media()
                {
                    Media_Type_ID = 4,
                    Name = "Gaming Computer",
                    Artist = "Jesse Golembiesky",
                    Acquired_Date = new DateTime(2014, 05, 05),
                    Acquired_Price = 899.00,
                    Location = "My Desk",
                    Is_Borrowed = false,
                    Was_Sold = false,
                    Was_Donated = false,
                    Market_Price = 599.99,
                    ImageName = "gamingcomputer"
                });

            }
        }
    }
}