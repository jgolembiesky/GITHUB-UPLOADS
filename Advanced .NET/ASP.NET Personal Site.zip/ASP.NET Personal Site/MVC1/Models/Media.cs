﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC1.Models
{
    public class Media
    {
        [Key]
        public int Media_ID { get; set; }
        public int Media_Type_ID { get; set;}
        [Required(ErrorMessage = "Name is Required")]
        [RegularExpression("..+", ErrorMessage = "Must be at least 2 characters long")]
        public string Name { get; set; }
        public string Medium { get; set; }
        public string Platform { get; set; }
        public string Artist { get; set; }
        public DateTime Acquired_Date { get; set; }
        public double Acquired_Price { get; set; }
        public string Location { get; set; }
        public bool Is_Borrowed { get; set; }
        public bool Was_Sold { get; set; }
        public bool Was_Donated { get; set; }
        public double Market_Price { get; set; }
        public double Sold_Price { get; set; }
        public string ImageName { get; set; }
        public int MediaType_ID { get; set; }
        public virtual MediaType MediaType { get; set; }



    }
}