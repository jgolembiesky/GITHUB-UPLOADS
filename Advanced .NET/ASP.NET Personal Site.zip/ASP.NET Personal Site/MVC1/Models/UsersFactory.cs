﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
namespace MVC1.Models
{
    public class UsersFactory : DbContext
    {
        public DbSet<User> Users { get; set; }

        public UsersFactory(): base("name=DefaultConnection")
        {
            Database.SetInitializer(new UserInitializer());
        }
    }
    public class UserInitializer : DropCreateDatabaseIfModelChanges<UsersFactory>
    {
        protected override void Seed(UsersFactory context)
        {
            context.Users.Add(new User()
            {
                FirstName = "Regina",
                LastName = "Ruano",
                Address = "54 Sumner Avenue",
                City = "Central Falls",
                State = "RI",
                Zip = "02865"
            });
            context.Users.Add(new User()
            {
                FirstName = "Steve",
                LastName = "Iwuc",
                Address = "82 Alaska Street",
                City = "Cumberland",
                State = "RI",
                Zip = "02864"
            });
            context.Users.Add(new User()
            {
                FirstName = "Billy",
                LastName = "Madison",
                Address = "87 Richmond Street",
                City = "Providence",
                State = "RI",
                Zip = "02865"
            });
            context.Users.Add(new User()
            {
                FirstName = "Michael",
                LastName = "Johnson",
                Address = "111 East India Avenue",
                City = "Pawtucket",
                State = "RI",
                Zip = "02686"
            });
            context.Users.Add(new User()
            {
                FirstName = "Jimmy",
                LastName = "Marbles",
                Address = "9 Wishbone Ave",
                City = "Cumberland",
                State = "RI",
                Zip = "02864"
            });
        }
    }
}